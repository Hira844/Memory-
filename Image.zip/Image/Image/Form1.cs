﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Image
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();

            System.Diagnostics.Process[] ps =
    System.Diagnostics.Process.GetProcesses();

            //配列から1つずつ取り出す
            foreach (System.Diagnostics.Process p in ps)
            {
                try
                {
                    comboBox1.Items.Add(p.ProcessName);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("エラー: {0}", ex.Message);
                }
            }
        }

        private void Button1_Click(object sender, EventArgs e)
        {
            System.Diagnostics.Process[] ps =
System.Diagnostics.Process.GetProcesses();

            //配列から1つずつ取り出す
            foreach (System.Diagnostics.Process p in ps)
            {
                try
                {
                    comboBox1.Items.Add(p.ProcessName);
                }
                catch (Exception ex)
                {
                    Console.WriteLine("エラー: {0}", ex.Message);
                }
            }
        }

        private static string ProcessName = "";
        private void Button2_Click(object sender, EventArgs e)
        {
            try
            {
                //インスタンスを作成 new VAMemory(プロセスの名前); で定義します。
                VAMemory vam = new VAMemory(ProcessName);
                //メモリを改竄します(値の方によって使用するメゾットは異なります。)
                vam.WriteInt32((IntPtr)Convert.ToInt32(textBox1.Text,16),int.Parse(textBox2.Text));
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message,"エラー",MessageBoxButtons.OK,MessageBoxIcon.Error);
            }
        }

        private void ComboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            ProcessName = comboBox1.SelectedItem.ToString();
        }
    }
}
